# Elvi

Elvi is a user-friendly website that makes it simple for people to find and book the best restaurants in their area.
With its intuitive interface and powerful search functionality, users can easily filter results based on their location, budget, and cuisine preferences.
Whether you're in the mood for Italian, Chinese, or israeli food, Elvi has something for everyone. And with its secure booking system, you can make reservations with confidence, knowing that your personal information is safe.
So if you're looking for an easy way to find and book a great restaurant, give Elvi a try today!

&nbsp;


## DB

You can find the db configuration in `db.config.js` file.
you might change the values according to your own environment.

```javascript
module.exports = {
    PORT: '27017',
    HOST: 'localhost',
    USER: 'root',
    PASSWORD: '',
    DATABASE: 'web'
}
```

&nbsp;

## Create / Remove the project's db
- Create the `web` db by using the following api:
```javascript
http://localhost:3000/createDB
```
Excecuting this api will also create all of the project collections:
- users
- orders
- resturants

&nbsp;

*** You might want to drop the whole db, in order to do so just use the following api:

- Drop the `web` db by using the following api:
```javascript
http://localhost:3000/dropDB
```

&nbsp;
## Login / Register
- Login
```javascript
[POST] http://localhost:3000/login
```
- Register
```javascript
[POST] http://localhost:3000/register
```

&nbsp;

## Users
- User model:
```javascript
{
    firstName: {
        type: String,
        required: true,
    },
    lastName: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    gender: {
        type: String,
        required: true,
    },
    phoneNumber: {
        type: String,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
}
```
- Create users collection:
```javascript
[GET] http://localhost:3000/users/create
```
- Insert one record to users:
```javascript
[POST] http://localhost:3000/users/insert
```
- Get all users:
```javascript
[GET] http://localhost:3000/users/select
```
- Drop users collection:
```javascript
[GET] http://localhost:3000/users/drop
```

&nbsp;

## Resturants
- Resturant model:
```javascript
{
    resturantName: {
        type: String,
        required: true,
    },
    logo: {
        type: String,
        required: true,
    },
    location: {
        type: String,
        required: true,
    },
    style: {
        type: String,
        required: true,
    },
    deliveries: {
        type: Boolean,
        required: true,
    },
    kosher: {
        type: Boolean,
        required: true,
    },
}
```
- Create resturants collection:
```javascript
[GET] http://localhost:3000/resturants/create
```
- Insert one record to resturants:
```javascript
[POST] http://localhost:3000/resturants/insert
```
- Get all resturants:
```javascript
[GET] http://localhost:3000/resturants/select
```
- Search resturants by parameters:
```javascript
[GET] http://localhost:3000/resturants/search?location=Afula&style=sushi&deliveries=true&kosher=false 
```
- Drop resturants collection:
```javascript
[GET] http://localhost:3000/resturants/drop
```