const currentPage = window.location.pathname;
const navLinks = document.querySelectorAll("nav a");

navLinks.forEach((link) => {
    if (link.href.includes(`${currentPage}`)) {
        link.classList.add("active");
    }
});

const form_logIn = document.getElementById("login-form");

const submitLogin = async (e) => {
    const email_logIn = document.getElementById("login-email");
    const password_logIn = document.getElementById("login-password");
    e.preventDefault();

    if (email_logIn.value === "" || password_logIn.value === "") {
        alert("please enter all fields");
        return;
    } else {
        const response = await fetch("http://localhost:3000/login", {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                email: email_logIn.value,
                password: password_logIn.value,
            }),
        }).catch((error) => {
            console.log(error);
            alert("A server error occurred while trying to login");
        });

        if (response?.status !== 200) {
            alert("email or password are incorrect");
        } else {
            const res = await response.json();
            sessionStorage.setItem(
                "userFullname",
                `${res.firstName} ${res.lastName}`
            );
            sessionStorage.setItem("token", res.token);
            window.location = "index.html";
        }
    }
};

const form_signUp = document.getElementById("register-form");

const submitRegister = async (e) => {
    const firstNameInput = document.getElementById("firstName");
    const lastNameInput = document.getElementById("lastName");
    const emailInput = document.getElementById("email");
    const phoneNumberInput = document.getElementById("phoneNumber");
    const genderInput = document.querySelector(
        'input[type="radio"][name="gender"]:checked'
    );
    const passwordInput = document.getElementById("password");
    const passwordReInput = document.getElementById("passwordre");
    e.preventDefault();

    if (
        firstNameInput.value === "" ||
        lastNameInput.value === "" ||
        emailInput.value === "" ||
        phoneNumberInput.value === "" ||
        passwordInput.value === "" ||
        passwordReInput.value === "" ||
        !genderInput
    ) {
        alert("please enter all fields");
        return;
    } else if (passwordInput.value != passwordReInput.value) {
        alert("passwods dosent match");
        return;
    } else {
        const response = await fetch("http://localhost:3000/register", {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                firstName: firstNameInput.value,
                lastName: lastNameInput.value,
                email: emailInput.value,
                gender: genderInput.getAttribute("id"),
                phoneNumber: phoneNumberInput.value,
                password: passwordInput.value,
            }),
        }).catch((error) => {
            console.log(error);
            alert("A server error occurred while trying to register user");
        });

        if (response?.status !== 200) {
            console.log(response);
            alert("A server error occurred while trying to register user");
        } else {
            window.location = "index.html";
            alert("Success! the user has been registered successfully");
        }
    }
};
if (form_signUp) {
    form_signUp.addEventListener("submit", submitRegister);
}

if (sessionStorage.getItem("token")) {
    if (form_logIn) {
        form_logIn.remove();
    }
    if (form_signUp) {
        form_signUp.remove();
    }
    document.querySelector(".signup-page").remove();
    document.querySelector(
        ".logged-in-user"
    ).innerHTML = `<button class="logout-btn" onclick="logout()">Logout</button>`;
    document.querySelector(".logged-in-user").style.display = "block";
}

if (form_logIn) {
    form_logIn.addEventListener("submit", submitLogin);
}

function logout() {
    sessionStorage.clear();
    window.location = "index.html";
}
