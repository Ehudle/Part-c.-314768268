module.exports = {
    PORT: '27017',
    HOST: 'localhost',
    USER: 'root',
    PASSWORD: '',
    DATABASE: 'web'
}