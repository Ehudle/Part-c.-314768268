const mongoose = require("mongoose");

const resturantSchema = new mongoose.Schema(
    {
        resturantName: {
            type: String,
            required: true,
        },
        logo: {
            type: String,
            required: true,
        },
        location: {
            type: String,
            required: true,
        },
        style: {
            type: String,
            required: true,
        },
        deliveries: {
            type: Boolean,
            required: true,
        },
        kosher: {
            type: Boolean,
            required: true,
        },
    },
    { timestamps: true }
);

const Resturant = mongoose.model("resturants", resturantSchema, "resturants");
module.exports = Resturant;
