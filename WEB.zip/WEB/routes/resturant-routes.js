const express = require("express");

const {
    createResturantsCollection,
    createResturant,
    getResturants,
    searchResturants,
    dropResturants,
} = require("../controller/resturant-controller");

const router = express.Router();

router.route("/resturants/create").get(createResturantsCollection);
router.route("/resturants/insert").post(createResturant);
router.route("/resturants/select").get(getResturants);
router.route("/resturants/search").get(searchResturants);
router.route("/resturants/drop").get(dropResturants);

module.exports = router;
