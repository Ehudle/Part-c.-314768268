const mongoose = require("mongoose");
const Resturant = require("../models/resturant-model");

exports.createResturantsCollection = async (req, res) => {
    try {
        await Resturant.createCollection();

        const resturants = [];

        resturants.push(
            await Resturant.create({
                resturantName: "Japanika",
                style: "sushi",
                logo: `https://images1.ynet.co.il/PicServer5/2017/03/20/7661424/logo_gapanika_(Large).jpg`,
                location: "Rishon Lezzion",
                deliveries: true,
                kosher: false,
            })
        );
        resturants.push(
            await Resturant.create({
                resturantName: "BBB",
                style: "burger",
                logo: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiTww4MTy8Mrb5t6kyWn56VXMnMKk-PlrgoQ&usqp=CAU`,
                location: "Tel Mond",
                deliveries: false,
                kosher: false,
            })
        );
        resturants.push(
            await Resturant.create({
                resturantName: "Schnitzel Kuki",
                style: "schnitzel",
                logo: `https://d25t2285lxl5rf.cloudfront.net/images/shops/6553.jepg`,
                location: "Beer Sheva",
                deliveries: true,
                kosher: true,
            })
        );
        resturants.push(
            await Resturant.create({
                resturantName: "Pizza Dominos",
                style: "pizza",
                logo: `https://media.easy.co.il/images/StaticLogo/9203842_1.jpg`,
                location: "Lod",
                deliveries: true,
                kosher: false,
            })
        );
        resturants.push(
            await Resturant.create({
                resturantName: "Cafe Cafe",
                style: "coffee",
                logo: `https://www.cafecafe.co.il/he/000Frames/site/images/logo-01.svg`,
                location: "Ashkelon",
                deliveries: true,
                kosher: true,
            })
        );
        resturants.push(
            await Resturant.create({
                resturantName: "Golda",
                style: "ice-cream",
                logo: `https://index-adumim.co.il/wp-content/uploads/2020/09/%D7%92%D7%9C%D7%99%D7%93%D7%94-%D7%92%D7%95%D7%9C%D7%93%D7%94.jpg`,
                location: "Tel Aviv",
                deliveries: true,
                kosher: true,
            })
        );
        resturants.push(
            await Resturant.create({
                resturantName: "Tzipora",
                style: "steak-house",
                logo: `https://shipudeytzipora-pt.co.il/wp-content/uploads/2020/06/logo-stz.png`,
                location: "Holon",
                deliveries: false,
                kosher: true,
            })
        );
        resturants.push(
            await Resturant.create({
                resturantName: "nam",
                style: "assian",
                logo: `https://vegan-friendly.co.il/img/logos/1565011871_%D7%A0%D7%9D%D7%90.png`,
                location: "Haifa",
                deliveries: true,
                kosher: false,
            })
        );
        resturants.push(
            await Resturant.create({
                resturantName: "Saida Bapark",
                style: "pubs",
                logo: `https://saidabapark.co.il/wp-content/uploads/2018/12/new-logo-transparent.png`,
                location: "Holon",
                deliveries: false,
                kosher: true,
            })
        );

        res.status(200).json(resturants);
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};

exports.createResturant = async (req, res) => {
    try {
        const newResturant = new Resturant(req.body);
        await newResturant.save();

        res.status(200).json(newResturant);
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};

exports.getResturants = async (req, res) => {
    try {
        const resturants = await Resturant.find({});
        if (resturants.length) {
            res.status(200).json(resturants);
        } else {
            res.status(200).json([]);
        }
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};

exports.searchResturants = async (req, res) => {
    try {
        const { resturantName, location, style, deliveries, kosher } =
            req.query;

        let options = {};
        if (resturantName) {
            options.resturantName = {
                $regex: resturantName,
                $options: "i",
            };
        }
        if (location) {
            options.location = {
                $regex: location,
                $options: "i",
            };
        }
        if (style) {
            options.style = style;
        }
        if (kosher) {
            options.kosher = kosher;
        }
        if (deliveries) {
            options.deliveries = deliveries;
        }

        const resturants = await Resturant.find(options);

        if (resturants.length) {
            res.status(200).json(resturants);
        } else {
            res.status(200).json([]);
        }
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};

exports.dropResturants = async (req, res) => {
    try {
        mongoose.connection.db
            .listCollections({ name: "resturants" })
            .next(async function (err, collinfo) {
                if (collinfo) {
                    await mongoose.connection.db
                        .collection("resturants")
                        .drop();
                    res.status(200).json({
                        message: "resturants collection has dropped",
                    });
                } else {
                    res.status(200).json({
                        message: "resturants collection was not found",
                    });
                }
            });
    } catch (err) {
        res.status(404).json({ message: err.message });
    }
};
